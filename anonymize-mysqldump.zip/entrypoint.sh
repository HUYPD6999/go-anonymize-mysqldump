#!/bin/bash
aws s3 cp s3://demo-athena1234/demo3.sql.gz .
gunzip demo3.sql.gz
cat demo3.sql | anonymize-mysqldump --config config.json 2> /var/log/errors.log | gzip > demo3_masked.sql.gz
aws s3 cp demo3_masked.sql.gz s3://demo-athena1234/
